//package com.formssi.mapper;
//
//import com.formssi.entity.Staff;
//import org.apache.ibatis.annotations.Mapper;
//
//import java.util.List;
//@Mapper
//public interface StaffMapper {
//    int deleteByPrimaryKey(Integer id);
//
//    int insert(Staff record);
//
//    Staff selectByPrimaryKey(Integer id);
//
//    List<Staff> selectAll();
//
//    int updateByPrimaryKey(Staff record);
//}
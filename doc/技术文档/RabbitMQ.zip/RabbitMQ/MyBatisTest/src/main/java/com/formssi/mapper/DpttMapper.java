//package com.formssi.mapper;
//
//import com.formssi.entity.Dptt;
//import org.apache.ibatis.annotations.Mapper;
//import java.util.List;
//@Mapper
//public interface DpttMapper {
//    int deleteByPrimaryKey(Integer no);
//
//    int insert(Dptt record);
//
//    Dptt selectByPrimaryKey(Integer no);
//
//    List<Dptt> selectAll();
//
//    int updateByPrimaryKey(Dptt record);
//}
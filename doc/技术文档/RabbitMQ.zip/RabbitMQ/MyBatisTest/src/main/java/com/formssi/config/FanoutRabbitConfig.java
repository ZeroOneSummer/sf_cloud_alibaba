package com.formssi.config;


import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FanoutRabbitConfig {


    //队列
    @Bean
    public Queue fanoutQueue1() {
            return new Queue("fanoutDpttQueue");
    }

    //交换机
    @Bean
    public FanoutExchange fanoutExchange1(){
        return new FanoutExchange("fanoutDpttExchange");
    }


    //3.将队列绑定到交换机
    @Bean
    public Binding fanoutBinding(Queue fanoutQueue1, FanoutExchange  fanoutExchange1){
        return BindingBuilder.bind(fanoutQueue1).to(fanoutExchange1);
    }
}

package com.formssi.config;

import com.formssi.rabbitEnum.RabbitExchangeEnum;
import com.formssi.tool.RabbitMessage;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("rabbitMessageSender")
public class RabbitMessageSender {
    @Autowired
    RabbitTemplate rabbitTemplate;

    public void sender(String msg){
        rabbitTemplate.convertAndSend("fanoutDpttExchange","ss",msg);
        System.out.println("发送fanout消息");
    }

    //Topic与direct模式都是通过rioutingKing来判断的,十分相似。exchange属性区分
    public void sender(RabbitExchangeEnum rabbitExchangeEnum, String routingKing, String msg){
        if (rabbitExchangeEnum==RabbitExchangeEnum.topicDpttExchange){
            rabbitTemplate.convertAndSend("topicDpttExchange1",routingKing,msg);
            System.out.println("发送topic消息");
        }else {
            rabbitTemplate.convertAndSend("directDpttExchange",routingKing,msg);
            System.out.println("发送direct消息");
        }
    }

}

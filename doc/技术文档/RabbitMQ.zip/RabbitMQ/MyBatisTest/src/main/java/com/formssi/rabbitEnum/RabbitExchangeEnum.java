package com.formssi.rabbitEnum;

public enum RabbitExchangeEnum {
       topicDpttExchange,
       directDpttQueue
}

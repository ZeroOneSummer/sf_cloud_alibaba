//package com.formssi.config;
//import lombok.Data;
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.context.annotation.Configuration;
//import java.util.HashMap;
//import java.util.List;
//
////配置文件配置交换器与队列
//@Data
//@Configuration
//@ConfigurationProperties(prefix="rabbit.connect,config")
//public class RabbitConnectConfig {
//   //队列名-routingKey集合
//    List<String> fanoutQueueNames;
//    List<HashMap<String,String>> tirectQueueNameAndKings;
//    List<HashMap<String,String>> topicQueueNameAndKings;
//    //交换器集合
//    List<String> ExchangeNames;
//}

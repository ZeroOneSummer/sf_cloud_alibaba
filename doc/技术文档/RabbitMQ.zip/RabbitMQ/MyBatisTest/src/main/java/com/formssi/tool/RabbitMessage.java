package com.formssi.tool;

import com.alibaba.fastjson.JSON;
import lombok.Data;

import java.io.Serializable;

@Data
public class RabbitMessage implements Serializable {
   private static final long serialVersionUID = 4084996990296644832L;
  private String body;

   public RabbitMessage(String body) {
      this.body = body;
   }

   public void setBody(String body){
     this.body=body;
  }

  public String getBody(){
     return  this.body;
  }

  public void setBody(Object body){
    this.body=JSON.toJSONString(body);
  }

  public Object  getObjectBody(){
     return JSON.parseObject(body);
  }

}

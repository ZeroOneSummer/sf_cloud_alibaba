package com.formssi.service;


import com.rabbitmq.client.Channel;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;
import java.io.IOException;

@Service
public class DpttService {

    @RabbitListener(queues = "fanoutDpttQueue")
    public void fanoutDptt(Message msg, Channel channel){
        try {
        System.out.println("fanout收到消息"+ msg);
        channel.basicAck(msg.getMessageProperties().getDeliveryTag(),true);
        System.out.println("ACK方式返回接受成功消息,立即删除消息-f");
       }catch (IOException e){
           System.out.println("返回ack异常");
       }
    }


    @RabbitListener(queues = "directDpttQueue")
    public void directDptt(Message msg, Channel channel){
        try {
            System.out.println("direct收到消息"+msg);
            channel.basicAck(msg.getMessageProperties().getDeliveryTag(),true);
            System.out.println("ACK方式返回接受成功消息,立即删除消息-d");
        }catch (IOException e){
            System.out.println("返回ack异常");
        }
    }

    @RabbitListener(queues = {"topicDpttQueue1","topicDpttQueue2"})
    public void topicDptt(Message msg, Channel channel){
        try {
            System.out.println("topic收到消息"+msg);
            channel.basicAck(msg.getMessageProperties().getDeliveryTag(),true);
            System.out.println("ACK方式返回接受成功消息,立即删除消息-t");
        }catch (IOException e){
            System.out.println("返回ack异常");
        }
    }
}

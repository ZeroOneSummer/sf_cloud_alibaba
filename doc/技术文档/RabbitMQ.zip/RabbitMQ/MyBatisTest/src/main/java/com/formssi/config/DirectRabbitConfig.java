package com.formssi.config;
import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DirectRabbitConfig {
    //1.创建一个名字为myDirectQueue的队列
    @Bean
    public Queue directQueue() {
        return new Queue("directDpttQueue");
    }

    //2.创建名字为myDirectExchange的交换机
    @Bean
    public DirectExchange directExchange() {
        return new DirectExchange("directDpttExchange");
    }

    //3.将队列绑定到交换机
    @Bean
    public Binding directBinding(Queue directQueue,DirectExchange directExchange){
       return BindingBuilder.bind(directQueue).to(directExchange).with("directKey");
    }
}

package com.formssi.config;
import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TopicRabbitConfig {
    //队列一
    @Bean
    public Queue topicQueue1(){
        return new Queue("topicDpttQueue1");
    }
    //队列一
    @Bean
    public Queue topicQueue2(){
        return new Queue("topicDpttQueue2");
    }
    //交换机
    @Bean
    public TopicExchange topicExchange(){
        return new TopicExchange("topicDpttExchange1");
    }

    //队列一绑定到交换机
    @Bean
    public Binding topicBinding1(Queue topicQueue1,TopicExchange topicExchange){
        return BindingBuilder.bind(topicQueue1).to(topicExchange).with("topic.#");//routingKey以abc开头的都可以接受到消息
    }
    @Bean
    public Binding topicBinding2(Queue topicQueue2,TopicExchange topicExchange){
        return BindingBuilder.bind(topicQueue2).to(topicExchange).with("#.com");//routingKey以abc开头的都可以接受到消息
    }
}

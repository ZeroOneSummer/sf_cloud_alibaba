package com.formssi.entity;

import java.io.Serializable;

public class Dptt implements Serializable {
    private static final long serialVersionUID = 4084996990296644842L;

    private Integer no;

    private String department;

    public Integer getNo() {
        return no;
    }

    public void setNo(Integer no) {
        this.no = no;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department == null ? null : department.trim();
    }
}
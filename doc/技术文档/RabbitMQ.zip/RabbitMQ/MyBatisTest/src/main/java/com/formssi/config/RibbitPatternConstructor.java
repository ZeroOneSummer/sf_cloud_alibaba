//package com.formssi.config;
//
//import org.springframework.amqp.core.*;
//import org.springframework.beans.BeansException;
//import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.ApplicationContextAware;
//import org.springframework.context.ConfigurableApplicationContext;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import java.util.stream.Collectors;
//
///**
// * 2022/01/26
// * Ribbit队列交换机构造器1
// */
//@Configuration
//public class RibbitPatternConstructor implements ApplicationContextAware {
//
//    RabbitConnectConfig rabbitConnectConfig = new RabbitConnectConfig();
//
//    //队列+routingKey集合，routingKey在与交换机绑定时，用以交换机将消息发至对应队列，交换机与队列为一对多关系
//    //模式交换机模式集合
//    FanoutExchange fanoutExchang;
//    DirectExchange directExchang;
//    TopicExchange topicExchang;
//
//    //队列一
//    @Bean
//    public void topicQueue(){
//
//    }
//
//
//    //创建交换机
//    public void constructorExchange(){
//       fanoutExchang =new FanoutExchange(rabbitConnectConfig.getExchangeNames().stream().filter(n ->n.substring(0,n.indexOf("_")).equals("fanout")).collect(Collectors.toList()).get(0));
//       directExchang =new DirectExchange(rabbitConnectConfig.getExchangeNames().stream().filter(n ->n.substring(0,n.indexOf("_")).equals("direct")).collect(Collectors.toList()).get(0));
//       topicExchang =new TopicExchange(rabbitConnectConfig.getExchangeNames().stream().filter(n ->n.substring(0,n.indexOf("_")).equals("topic")).collect(Collectors.toList()).get(0));
//    }
//
//    @Override
//    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
//        ConfigurableListableBeanFactory beanFactory=((ConfigurableApplicationContext)applicationContext).getBeanFactory();
//       for(int i=rabbitConnectConfig.getFanoutQueueNames().size();i<=0;i--){
//                beanFactory.registerSingleton("fanoutBinding"+i,BindingBuilder.bind(new Queue(rabbitConnectConfig.getFanoutQueueNames().get(i-1))));
//       }
//    }
//
//    //队列一绑定到交换机
//    @Bean
//    public Binding topicBinding(Queue queue, TopicExchange topicExchange){
//        return BindingBuilder.bind(queue).to(topicExchange).with("topic.#");//routingKey以abc开头的都可以接受到消息
//    }
//}

package com.formssi;
import com.formssi.config.RabbitMessageSender;
import com.formssi.rabbitEnum.RabbitExchangeEnum;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class Test1 {
    @Autowired
    RabbitMessageSender rabbitMessageSender;


    @Test
    public void dpttTest() {
        rabbitMessageSender.sender("fanout模式你好!");
        rabbitMessageSender.sender(RabbitExchangeEnum.directDpttQueue,"directKey","direct模式你好");
        rabbitMessageSender.sender(RabbitExchangeEnum.topicDpttExchange,"topic.Key","topic模式你好1");
        rabbitMessageSender.sender(RabbitExchangeEnum.topicDpttExchange,"TOP.com","topic模式你好");
    }


}
